script.on_event(defines.events.on_resource_depleted, function(event)

	if global.generator == nil then
		global.generator = game.create_random_generator()
  	end

	event.entity.surface.create_entity({name=event.entity.name, amount = global.generator(15000, 20000), position = event.entity.position})

end)