for k, v in pairs(data.raw.resource) do
   if v.infinite == true then
   	v.infinite_depletion_amount = 0
   end
end