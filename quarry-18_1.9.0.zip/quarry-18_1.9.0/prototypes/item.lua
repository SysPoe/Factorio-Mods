data:extend({
  {
    type = "item",
    name = "quarry",
    icon = "__quarry-18__/graphics/quarry/quarry-icon.png",
    icon_size = 32,
    subgroup = "extraction-machine",
    order = "a[items]-m[quarry]",
    place_result = "quarry",
    stack_size = 20
  },
  {
    type = "item",
    name = "quarry-mk2",
    icon = "__quarry-18__/graphics/quarry-mk2/quarry-icon.png",
    icon_size = 32,
    subgroup = "extraction-machine",
    order = "a[items]-n[quarry-mk2]",
    place_result = "quarry-mk2",
    stack_size = 20
  },
  {
    type = "item",
    name = "quarry-mk3",
    icon = "__quarry-18__/graphics/quarry-mk3/quarry-icon.png",
    icon_size = 32,
    subgroup = "extraction-machine",
    order = "a[items]-o[quarry-mk3]",
    place_result = "quarry-mk3",
    stack_size = 20
  },
  {
    type = "item",
    name = "mineral-rich-stone",
    icon = "__quarry-18__/graphics/mineral-rich-stone.png",
    icon_size = 32,
    subgroup = "raw-resource",
    order = "a[items]-m[mineral-rich-stone]",
    stack_size = 50
  },
  {
    type = "item",
    name = "crusher",
    icon = "__quarry-18__/graphics/crusher/crusher-icon.png",
    icon_size = 32,
    subgroup = "extraction-machine",
    order = "a[items]-p[crusher]",
    place_result = "crusher",
    stack_size = 20
  }
})