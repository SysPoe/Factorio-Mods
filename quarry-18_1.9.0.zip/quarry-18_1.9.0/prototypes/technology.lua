table.insert(data.raw["technology"]["advanced-material-processing"].effects,
  {
    type = "unlock-recipe",
    recipe = "quarry-mk2"
  }
)
table.insert(data.raw["technology"]["advanced-material-processing-2"].effects,
  {
    type = "unlock-recipe",
    recipe = "quarry-mk3"
  }
)