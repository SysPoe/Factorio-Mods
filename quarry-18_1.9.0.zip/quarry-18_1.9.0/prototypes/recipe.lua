data:extend({
  {
    type = "recipe",
    name = "quarry",
    ingredients =
    {
      {"iron-plate", 20},
      {"iron-gear-wheel", 10},
      {"electronic-circuit", 20}
    },
    result = "quarry",
    energy_required = 5
  },
  {
    type = "recipe",
    name = "quarry-mk2",
    enabled = false,
    ingredients =
    {
      {"quarry", 2},
      {"steel-plate", 10}
    },
    result = "quarry-mk2",
    energy_required = 10
  },
  {
    type = "recipe",
    name = "quarry-mk3",
    enabled = false,
    ingredients =
    {
      {"quarry-mk2", 2},
      {"steel-plate", 20},
      {"advanced-circuit", 20}
    },
    result = "quarry-mk3",
    energy_required = 15
  },
  {
    type = "recipe",
    name = "crusher",
    enabled = settings.startup["quarry-complex-mode"].value,
    ingredients =
    {
      {"iron-plate", 65},
      {"iron-gear-wheel", 20},
      {"electronic-circuit", 20}
    },
    result = "crusher",
    energy_required = 10
  }
})