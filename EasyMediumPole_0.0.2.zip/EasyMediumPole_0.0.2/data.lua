data.raw["recipe"]["medium-electric-pole"].ingredients[2][1] = "iron-plate"
data.raw["recipe"]["medium-electric-pole"].enabled = true
data.raw["technology"]["electric-energy-distribution-1"].effects[1] = nil
