require("prototypes.item")
require("prototypes.recipe")
require("prototypes.entity")
require("prototypes.technology") -- needs to come after recipe