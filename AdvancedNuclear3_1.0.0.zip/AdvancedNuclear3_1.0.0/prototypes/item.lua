---Copy entities from data.raw---
local advExchange = table.deepcopy(data.raw["item"]["heat-exchanger"])
local advTurbine = table.deepcopy(data.raw["item"]["steam-turbine"])
local advPipe = table.deepcopy(data.raw["item"]["heat-pipe"])
local advReactor = table.deepcopy(data.raw["item"]["nuclear-reactor"])

---Advanced Heat Exchanger---
advExchange.name = "adv-heat-exchanger-2"
advExchange.place_result = "adv-heat-exchanger-2"

---Advanced Steam Turbine---
advTurbine.name = "adv-steam-turbine-2"
advTurbine.place_result = "adv-steam-turbine-2"

---Advanced Heat Pipe---
advPipe.name = "adv-heat-pipe-2"
advPipe.place_result = "adv-heat-pipe-2"

---Advanced Nuclear Reactor---
advReactor.name = "adv-nuclear-reactor-2"
advReactor.place_result = "adv-nuclear-reactor-2"

---Put new entities into data.raw---
data.raw["item"]["adv-heat-exchanger-2"] = advExchange
data.raw["item"]["adv-steam-turbine-2"] = advTurbine
data.raw["item"]["adv-heat-pipe-2"] = advPipe
data.raw["item"]["adv-nuclear-reactor-2"] = advReactor
