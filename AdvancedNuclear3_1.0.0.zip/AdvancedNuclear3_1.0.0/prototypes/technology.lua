local recipes = {
  "adv-nuclear-reactor-2",
  "adv-heat-exchanger-2",
  "adv-steam-turbine-2",
  "adv-heat-pipe-2"
}
local recipe = nil
local reactor_tech = data.raw["technology"]["nuclear-power"]

if reactor_tech then
  if not reactor_tech.effects then reactor_tech.effects = {} end
  for _, recipe in pairs(recipes) do
    table.insert(reactor_tech.effects, {type = "unlock-recipe", recipe = recipe})
  end
else
  for _, recipe in pairs(recipes) do
      data.raw.recipe[recipe].enabled = true
  end
end