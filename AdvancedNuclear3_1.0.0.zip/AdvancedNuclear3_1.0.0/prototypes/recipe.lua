local mult = settings.startup["recipe-multiplier"].value


---Copy entities from data.raw---
local advExchange = table.deepcopy(data.raw["recipe"]["heat-exchanger"])
local advTurbine = table.deepcopy(data.raw["recipe"]["steam-turbine"])
local advPipe = table.deepcopy(data.raw["recipe"]["heat-pipe"])
local advReactor = table.deepcopy(data.raw["recipe"]["nuclear-reactor"])

---Advanced Heat Exchanger---
  --Constant
advExchange.name = "adv-heat-exchanger-2"
advExchange.result = "adv-heat-exchanger-2"
  --Changing
advExchange.enabled = false
advExchange.ingredients = {{"heat-exchanger", math.floor(mult*1)}, {"processing-unit", math.floor(mult*10)}}


---Advanced Steam Turbine---
  --Constant
advTurbine.name = "adv-steam-turbine-2"
advTurbine.result = "adv-steam-turbine-2"
  --Changing
advTurbine.enabled = false
advTurbine.ingredients = {{"steam-turbine", math.floor(mult*1)}, {"processing-unit", math.floor(mult*10)}}

---Advanced Heat Pipe---
  --Constant
advPipe.name = "adv-heat-pipe-2"
advPipe.result = "adv-heat-pipe-2"
  --Changing
advPipe.enabled = false
advPipe.ingredients = {{"heat-pipe", math.floor(mult*1)}}

---Advanced Nuclear Reactor---
  --Constant
advReactor.name = "adv-nuclear-reactor-2"
advReactor.result = "adv-nuclear-reactor-2"
  --Changing
advReactor.enabled = false
advReactor.ingredients = 
    {
      {"nuclear-reactor", math.floor(mult*1)},
      {"processing-unit", math.floor(mult*100)},
    }

---Put new entities into data.raw---
data.raw["recipe"]["adv-heat-exchanger-2"] = advExchange
data.raw["recipe"]["adv-steam-turbine-2"] = advTurbine
data.raw["recipe"]["adv-heat-pipe-2"] = advPipe
data.raw["recipe"]["adv-nuclear-reactor-2"] = advReactor
