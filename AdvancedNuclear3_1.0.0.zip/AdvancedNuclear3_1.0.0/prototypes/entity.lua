--local turbinePower = settings.startup["turbine-power-output"].value or 1
local turbineMW = settings.startup["turbine-power-output-mw"].value or 5.82
local exchangerMW = settings.startup["exchanger-power-output-mw"].value or 10
local reactorConsumption = settings.startup["reactor-consumption-mw"].value or 40
local adjust_efficiency = settings.startup["reactor-efficiency-change"].value or true

local tempChange = turbineMW / (60 * .0002) -- assuming 60 fluid/s
local steamTemp = 15 + tempChange
local maxTemp = steamTemp*2
local reacPower = reactorConsumption
local reactorPower = reacPower.."MW"
local reactorEff = 1

if adjust_efficiency then
  reactorEff = turbineMW / reacPower
  reacPower = reactorConsumption * reactorEff
  reactorPower = reacPower.."MW"
end

---Copy entities from data.raw---
local advExchange = table.deepcopy(data.raw["boiler"]["heat-exchanger"])
local advTurbine = table.deepcopy(data.raw["generator"]["steam-turbine"])
local advPipe = table.deepcopy(data.raw["heat-pipe"]["heat-pipe"])
local advReactor = table.deepcopy(data.raw["reactor"]["nuclear-reactor"])

---Advanced Heat Exchanger---
  --Constants
advExchange.name = "adv-heat-exchanger-2"
advExchange.minable = {hardness = 0.2, mining_time = 0.5, result = "adv-heat-exchanger-2"}
  --Changing
--advExchange.energy_consumption = "40MW"
advExchange.energy_consumption = exchangerMW .. "MW"
advExchange.target_temperature = steamTemp --Changes
advExchange.energy_source =
    {
      type = "heat",
      max_temperature = maxTemp, --Changes
      specific_heat = "1MJ",
      max_transfer = "1000GW",
      connections =
      {
        {
          position = {0, 0.5},
          direction = defines.direction.south
        }
      },
      pipe_covers =

        make_4way_animation_from_spritesheet(
        {
          filename = "__base__/graphics/entity/heat-exchanger/heatex-endings.png",
          line_length = 4,
          width = 32,
          height = 32,
          direction_count = 4,
          hr_version = {
            filename = "__base__/graphics/entity/heat-exchanger/hr-heatex-endings.png",
            line_length = 4,
            width = 64,
            height = 64,
            direction_count = 4,
            scale = 0.5
          }
        })

    }


---Advanced Steam Turbine---
  --Constants
advTurbine.name = "adv-steam-turbine-2"
advTurbine.minable = {mining_time = 1, result = "adv-steam-turbine-2"}
  --Changing
advTurbine.fluid_usage_per_tick = 1 --Reduces number of turbines needed
advTurbine.maximum_temperature = steamTemp

advTurbine.fluid_box.maximum_temperature = steamTemp
--advTurbine.max_power_output = ((advTurbine.fluid_usage_per_tick * 60) * (tempChange * .0002)) .. "MW"
advTurbine.max_power_output = turbineMW .. "MW"


---Advanced Heat Pipe---
  --Constants
advPipe.name = "adv-heat-pipe-2"
advPipe.minable = {hardness = 0.2, mining_time = 0.5, result = "adv-heat-pipe-2"}
  --Changing
advPipe.heat_buffer =
    {
      max_temperature = maxTemp, --Changes
      specific_heat = "1MJ",
      max_transfer = "1000GW",
      connections =
      {
        {
          position = {0, 0},
          direction = defines.direction.north
        },
        {
          position = {0, 0},
          direction = defines.direction.east
        },
        {
          position = {0, 0},
          direction = defines.direction.south
        },
        {
          position = {0, 0},
          direction = defines.direction.west
        }
      }
    }

---Advanced Nuclear Reactor---
  --Constants
advReactor.name = "adv-nuclear-reactor-2"
advReactor.minable = {mining_time = 1.5, result = "adv-nuclear-reactor-2"}
  --Changing
advReactor.consumption = reactorPower
advReactor.energy_source.effectivity = reactorEff
advReactor.heat_buffer =
    {
      max_temperature = maxTemp, --Changes
      specific_heat = "10MJ",
      max_transfer = "1000GW", --Change if needed
      connections =
      {
        {
          position = {-2, -2},
          direction = defines.direction.north
        },
        {
          position = {0, -2},
          direction = defines.direction.north
        },
        {
          position = {2, -2},
          direction = defines.direction.north
        },
        {
          position = {2, -2},
          direction = defines.direction.east
        },
        {
          position = {2, 0},
          direction = defines.direction.east
        },
        {
          position = {2, 2},
          direction = defines.direction.east
        },
        {
          position = {2, 2},
          direction = defines.direction.south
        },
        {
          position = {0, 2},
          direction = defines.direction.south
        },
        {
          position = {-2, 2},
          direction = defines.direction.south
        },
        {
          position = {-2, 2},
          direction = defines.direction.west
        },
        {
          position = {-2, 0},
          direction = defines.direction.west
        },
        {
          position = {-2, -2},
          direction = defines.direction.west
        }
      }
    }

---Put new entities into data.raw---
data.raw["boiler"]["adv-heat-exchanger-2"] = advExchange
data.raw["generator"]["adv-steam-turbine-2"] = advTurbine
data.raw["heat-pipe"]["adv-heat-pipe-2"] = advPipe
data.raw["reactor"]["adv-nuclear-reactor-2"] = advReactor
