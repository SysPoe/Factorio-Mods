data:extend({
    {
	  type = "double-setting",
	  name = "turbine-power-output-mw",
      order = "a",
	  setting_type = "startup",
	  default_value = 5.82
	},
	{
	  type = "double-setting",
	  name = "exchanger-power-output-mw",
      order = "b",
	  setting_type = "startup",
	  default_value = 10.0
	},
	{
	  type = "double-setting",
	  name = "reactor-consumption-mw",
      order = "c",
	  setting_type = "startup",
	  default_value = 40.0
	},
	{
	  type = "bool-setting",
	  name = "reactor-efficiency-change",
      order = "d",
	  setting_type = "startup",
	  default_value = true
	},
	{
	  type = "double-setting",
	  name = "recipe-multiplier",
      order = "e",
	  setting_type = "startup",
	  default_value = 1.0
	}
})