function replace_entities()
  local surface = game.player.surface
  local forc = game.player.force
  for _,ent in pairs(surface.find_entities_filtered{name = "nuclear-reactor"}) do
    local pos = ent.position
	local dir = ent.direction
	ent.destroy()
	surface.create_entity{name="adv-nuclear-reactor-2",position = pos,direction = dir,force = forc}
  end
  for _,ent in pairs(surface.find_entities_filtered{name = "heat-pipe"}) do
    local pos = ent.position
	local dir = ent.direction
	ent.destroy()
	surface.create_entity{name="adv-heat-pipe-2",position = pos,direction = dir,force = forc}
  end
  for _,ent in pairs(surface.find_entities_filtered{name = "heat-exchanger"}) do
    local pos = ent.position
	local dir = ent.direction
	ent.destroy()
	surface.create_entity{name="adv-heat-exchanger-2",position = pos,direction = dir,force = forc}
  end
  for _,ent in pairs(surface.find_entities_filtered{name = "steam-turbine"}) do
    local pos = ent.position
	local dir = ent.direction
	ent.destroy()
	surface.create_entity{name="adv-steam-turbine-2",position = pos,direction = dir,force = forc}
  end
end
commands.add_command("replace-nuclear","Replaces all nuclear components on your map with the components from the Advanced Nuclear mod.",replace_entities)

function on_configuration_changed(event)
  local force =  nil
  local recipes = {
    "adv-nuclear-reactor-2",
    "adv-heat-exchanger-2",
    "adv-steam-turbine-2",
    "adv-heat-pipe-2"
  }
  local recipe = nil

  for _, force in pairs(game.forces) do
    if force.technologies["nuclear-power"] and force.technologies["nuclear-power"].researched == true then
      for _, recipe in pairs(recipes) do
        force.recipes[recipe].enabled = true
      end
    end
  end
end

script.on_init(on_configuration_changed)
script.on_configuration_changed(on_configuration_changed)