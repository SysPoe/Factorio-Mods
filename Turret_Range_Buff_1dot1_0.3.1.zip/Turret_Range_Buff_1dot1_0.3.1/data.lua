data.raw["ammo-turret"]["gun-turret"].attack_parameters.range = settings.startup["gun-turret"].value
data.raw["electric-turret"]["laser-turret"].attack_parameters.range = settings.startup["laser-turret"].value
data.raw["fluid-turret"]["flamethrower-turret"].attack_parameters.range = settings.startup["flamethrower-turret"].value