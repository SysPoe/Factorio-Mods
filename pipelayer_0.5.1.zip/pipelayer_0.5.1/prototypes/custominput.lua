data:extend{
  {
    type = "custom-input",
    name = "pipelayer-toggle-editor-view",
    key_sequence = "CONTROL + P",
  },
  {
    type = "custom-input",
    name = "pipelayer-toggle-connector-mode",
    key_sequence = "SHIFT + P",
  },
}