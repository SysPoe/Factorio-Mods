data:extend{
  {
    type = "bool-setting",
    name = "beltlayer-deconstruction-warning",
    setting_type = "runtime-per-user",
    default_value = true,
  },
}