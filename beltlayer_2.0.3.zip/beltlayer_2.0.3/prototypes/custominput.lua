data:extend{
  {
    type = "custom-input",
    name = "beltlayer-toggle-editor-view",
    key_sequence = "CONTROL + B",
  },
}