--https://lua-api.factorio.com/latest/events.html#on_rocket_launched
--on_rocket_launched

--Called when the rocket is launched.

--Contains
--rocket :: LuaEntity
--rocket_silo :: LuaEntity (optional)
--player_index :: uint (optional): The player that is riding the rocket, if any.

script.on_event(defines.events.on_rocket_launched, function(event)
	local rocket_silo = event.rocket_silo
	if rocket_silo then
		local surface = rocket_silo.surface
		local force = rocket_silo.force
		if surface and force then
			local solar_power_multiplier = surface.solar_power_multiplier
			solar_power_multiplier = solar_power_multiplier + 0.1
--			game.print ('[Orbital Solar Power]: solar_power_multiplier: ' .. solar_power_multiplier)
			surface.solar_power_multiplier = solar_power_multiplier
		end
	end
end)