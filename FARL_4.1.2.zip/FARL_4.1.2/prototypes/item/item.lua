data:extend(
    {
        {
            type = "item-with-entity-data",
            name = "farl",
            icon = "__FARL__/graphics/icons/farl.png",
            icon_size = 32,
            icon_mipmaps = 0,
            subgroup = "train-transport",
            order = "a[train-system]-j[farl]",
            place_result = "farl",
            stack_size = 5
        }
    })
