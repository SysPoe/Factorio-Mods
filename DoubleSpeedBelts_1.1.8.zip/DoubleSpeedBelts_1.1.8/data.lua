

-- local collision_layer = "layer-13"
-- table.insert (data.raw.item.landfill.place_as_tile.condition, collision_layer)
-- table.insert (data.raw.tile.deepwater.collision_mask, collision_layer)