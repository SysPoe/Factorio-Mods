data:extend({
	-- Startup
	{
		type = "bool-setting",
		name = "dsb-autoprototypes",
		setting_type = "startup",
		default_value = true,
		order = "a"
	}
})