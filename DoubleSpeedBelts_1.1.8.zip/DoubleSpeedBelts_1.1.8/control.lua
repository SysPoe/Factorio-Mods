-- script.on_event(defines.events.on_gui_click, function(event)

-- element :: LuaGuiElement: The clicked element.
-- player_index :: uint: The player who did the clicking.
-- button :: defines.mouse_button_type: The mouse button used if any.
-- alt :: boolean: If alt was pressed.
-- control :: boolean: If control was pressed.
-- shift :: boolean: If shift was pressed.
  -- game.print ('element' .. event.element)
  -- game.print ('button' .. event.button)
  -- game.print ('alt' .. tostring(event.alt))
  -- game.print ('control' .. tostring(event.control))
  -- game.print ('shift' .. tostring(event.shift))
  
-- end)