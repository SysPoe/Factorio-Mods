data:extend({
  {
    type = "bool-setting",
    name = "portals-disable-long-distance-placing",
    setting_type = "runtime-global",
    default_value = false
  },
  {
    type = "bool-setting",
    name = "portals-dont-number-portal-pair-one",
    setting_type = "runtime-global",
    default_value = false
  }
})
